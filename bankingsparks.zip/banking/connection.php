<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bankdatabase";
$conn = mysqli_connect($servername,$username,$password,$dbname);
/*
if($conn)
{
	echo "Connection Succesfull";
}
else
{
	echo "Connection failed".mysqli_connect_error();
}
*/
?>